/*!
 * vue-admin-better
 * GitHub: https://github.com/zxwk1998/vue-admin-better
 * Gitee: https://gitee.com/chu1204505056/vue-admin-better
 *
 * 版权所有 (c) 2025 vue-admin-better
 * 本项目使用 MIT 许可证
 * 构建时间: 2026-1-9 03:25:34
 */
"use strict";
(self["webpackChunkvue_admin_better"] = self["webpackChunkvue_admin_better"] || []).push([["1836"], {
77322: (function (__unused_rspack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  getList: function() { return getList; }
});
/* import */ var _utils_request__rspack_import_0 = __webpack_require__(51860);

function getList(data) {
  return (0,_utils_request__rspack_import_0["default"])({
    url: '/goodsList/getList',
    method: 'post',
    data
  });
}

}),
78007: (function (module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
/* import */ var _node_modules_pnpm_css_loader_7_1_2_rspack_core_1_7_1_webpack_5_104_1_node_modules_css_loader_dist_runtime_noSourceMaps_js__rspack_import_0 = __webpack_require__(40015);
/* import */ var _node_modules_pnpm_css_loader_7_1_2_rspack_core_1_7_1_webpack_5_104_1_node_modules_css_loader_dist_runtime_noSourceMaps_js__rspack_import_0_default = /*#__PURE__*/__webpack_require__.n(_node_modules_pnpm_css_loader_7_1_2_rspack_core_1_7_1_webpack_5_104_1_node_modules_css_loader_dist_runtime_noSourceMaps_js__rspack_import_0);
/* import */ var _node_modules_pnpm_css_loader_7_1_2_rspack_core_1_7_1_webpack_5_104_1_node_modules_css_loader_dist_runtime_api_js__rspack_import_1 = __webpack_require__(84176);
/* import */ var _node_modules_pnpm_css_loader_7_1_2_rspack_core_1_7_1_webpack_5_104_1_node_modules_css_loader_dist_runtime_api_js__rspack_import_1_default = /*#__PURE__*/__webpack_require__.n(_node_modules_pnpm_css_loader_7_1_2_rspack_core_1_7_1_webpack_5_104_1_node_modules_css_loader_dist_runtime_api_js__rspack_import_1);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_pnpm_css_loader_7_1_2_rspack_core_1_7_1_webpack_5_104_1_node_modules_css_loader_dist_runtime_api_js__rspack_import_1_default()((_node_modules_pnpm_css_loader_7_1_2_rspack_core_1_7_1_webpack_5_104_1_node_modules_css_loader_dist_runtime_noSourceMaps_js__rspack_import_0_default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, ".page-header{background:linear-gradient(135deg, #4d8af0 0%, #1a56db 100%);border-radius:12px;padding:30px;margin-bottom:24px;color:#fff;box-shadow:0 8px 32px rgba(102,126,234,.3)}.page-header .header-content{display:flex;justify-content:space-between;align-items:center}.page-header .header-content .header-left .page-title{font-size:2rem;font-weight:700;margin:0 0 8px 0;display:flex;align-items:center;gap:12px}.page-header .header-content .header-left .page-title .vab-icon{font-size:1.8rem}.page-header .header-content .header-left .page-description{font-size:1rem;opacity:.9;margin:0}.page-header .header-content .header-right{display:flex;align-items:center;gap:8px;font-size:1.1rem;font-weight:600}.page-header .header-content .header-right .vab-icon{font-size:1.3rem}", ""]);
// Exports
/* export default */ __webpack_exports__["default"] = (___CSS_LOADER_EXPORT___);


}),
79464: (function (module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
/* import */ var _node_modules_pnpm_css_loader_7_1_2_rspack_core_1_7_1_webpack_5_104_1_node_modules_css_loader_dist_runtime_noSourceMaps_js__rspack_import_0 = __webpack_require__(40015);
/* import */ var _node_modules_pnpm_css_loader_7_1_2_rspack_core_1_7_1_webpack_5_104_1_node_modules_css_loader_dist_runtime_noSourceMaps_js__rspack_import_0_default = /*#__PURE__*/__webpack_require__.n(_node_modules_pnpm_css_loader_7_1_2_rspack_core_1_7_1_webpack_5_104_1_node_modules_css_loader_dist_runtime_noSourceMaps_js__rspack_import_0);
/* import */ var _node_modules_pnpm_css_loader_7_1_2_rspack_core_1_7_1_webpack_5_104_1_node_modules_css_loader_dist_runtime_api_js__rspack_import_1 = __webpack_require__(84176);
/* import */ var _node_modules_pnpm_css_loader_7_1_2_rspack_core_1_7_1_webpack_5_104_1_node_modules_css_loader_dist_runtime_api_js__rspack_import_1_default = /*#__PURE__*/__webpack_require__.n(_node_modules_pnpm_css_loader_7_1_2_rspack_core_1_7_1_webpack_5_104_1_node_modules_css_loader_dist_runtime_api_js__rspack_import_1);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_pnpm_css_loader_7_1_2_rspack_core_1_7_1_webpack_5_104_1_node_modules_css_loader_dist_runtime_api_js__rspack_import_1_default()((_node_modules_pnpm_css_loader_7_1_2_rspack_core_1_7_1_webpack_5_104_1_node_modules_css_loader_dist_runtime_noSourceMaps_js__rspack_import_0_default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, ".goods-list-container .goods-list-card-body[data-v-5a64b9e8]{position:relative;text-align:center;cursor:pointer}.goods-list-container .goods-list-card-body .goods-list-tag-group[data-v-5a64b9e8]{position:absolute;top:10px;right:5px;z-index:9}.goods-list-container .goods-list-card-body .goods-list-image-group[data-v-5a64b9e8]{height:400px;overflow:hidden}.goods-list-container .goods-list-card-body .goods-list-image-group .goods-list-image[data-v-5a64b9e8]{width:100%;height:400px;transition:all ease-in-out .3s}.goods-list-container .goods-list-card-body .goods-list-image-group .goods-list-image[data-v-5a64b9e8]:hover{transform:scale(1.1)}.goods-list-container .goods-list-card-body .goods-list-title[data-v-5a64b9e8]{margin:8px 0;font-size:16px;font-weight:bold}.goods-list-container .goods-list-card-body .goods-list-description[data-v-5a64b9e8]{font-size:14px;color:#808695}.goods-list-container .goods-list-card-body .goods-list-price[data-v-5a64b9e8]{margin:8px 0;font-size:14px;color:#fa8c16}.goods-list-container .goods-list-card-body .goods-list-price s[data-v-5a64b9e8]{color:#c5c8ce}", ""]);
// Exports
/* export default */ __webpack_exports__["default"] = (___CSS_LOADER_EXPORT___);


}),
94832: (function (__unused_rspack_module, __webpack_exports__, __webpack_require__) {
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": function() { return /* binding */ VabPageHeader; }
});

;// CONCATENATED MODULE: ./node_modules/.pnpm/vue-loader@15.9.8_@vue+compiler-sfc@3.5.26_css-loader@7.1.2_@rspack+core@1.7.1_webpack@_1aa4f1bbe7085d478bfddd6730367f21/node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/.pnpm/vue-loader@15.9.8_@vue+compiler-sfc@3.5.26_css-loader@7.1.2_@rspack+core@1.7.1_webpack@_1aa4f1bbe7085d478bfddd6730367f21/node_modules/vue-loader/lib/index.js??vue-loader-options!./src/components/VabPageHeader/index.vue?vue&type=template&id=2b14fb2d&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticClass:"page-header",class:_vm.customClass},[_c('div',{staticClass:"header-content"},[_c('div',{staticClass:"header-left"},[_c('h1',{staticClass:"page-title"},[(_vm.icon)?_c('vab-icon',{attrs:{"icon":_vm.icon}}):_vm._e(),_vm._v("\n        "+_vm._s(_vm.title)+"\n      ")],1),(_vm.description)?_c('p',{staticClass:"page-description",domProps:{"innerHTML":_vm._s(_vm.description)}}):_vm._e()]),(_vm.rightIcon || _vm.rightText)?_c('div',{staticClass:"header-right"},[_vm._t("right",function(){return [(_vm.rightIcon)?_c('vab-icon',{attrs:{"icon":_vm.rightIcon}}):_vm._e(),(_vm.rightText)?_c('span',[_vm._v(_vm._s(_vm.rightText))]):_vm._e()]})],2):_vm._e()])])}
var staticRenderFns = []


;// CONCATENATED MODULE: ./node_modules/.pnpm/babel-loader@10.0.0_@babel+core@7.28.5_webpack@5.104.1/node_modules/babel-loader/lib/index.js??clonedRuleSet-1[0].rules[0].use!./node_modules/.pnpm/vue-loader@15.9.8_@vue+compiler-sfc@3.5.26_css-loader@7.1.2_@rspack+core@1.7.1_webpack@_1aa4f1bbe7085d478bfddd6730367f21/node_modules/vue-loader/lib/index.js??vue-loader-options!./src/components/VabPageHeader/index.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* export default */ var VabPageHeadervue_type_script_lang_js_ = ({
  name: 'VabPageHeader',
  props: {
    title: {
      type: String,
      required: true
    },
    description: {
      type: String,
      default: ''
    },
    icon: {
      type: Array,
      default: () => []
    },
    rightIcon: {
      type: Array,
      default: () => []
    },
    rightText: {
      type: String,
      default: ''
    },
    customClass: {
      type: String,
      default: ''
    }
  }
});
;// CONCATENATED MODULE: ./src/components/VabPageHeader/index.vue?vue&type=script&lang=js&
 /* export default */ var components_VabPageHeadervue_type_script_lang_js_ = (VabPageHeadervue_type_script_lang_js_); 
// EXTERNAL MODULE: ./node_modules/.pnpm/style-loader@4.0.0_webpack@5.104.1/node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js
var injectStylesIntoStyleTag = __webpack_require__(64812);
var injectStylesIntoStyleTag_default = /*#__PURE__*/__webpack_require__.n(injectStylesIntoStyleTag);
// EXTERNAL MODULE: ./node_modules/.pnpm/style-loader@4.0.0_webpack@5.104.1/node_modules/style-loader/dist/runtime/styleDomAPI.js
var styleDomAPI = __webpack_require__(27381);
var styleDomAPI_default = /*#__PURE__*/__webpack_require__.n(styleDomAPI);
// EXTERNAL MODULE: ./node_modules/.pnpm/style-loader@4.0.0_webpack@5.104.1/node_modules/style-loader/dist/runtime/insertBySelector.js
var insertBySelector = __webpack_require__(51511);
var insertBySelector_default = /*#__PURE__*/__webpack_require__.n(insertBySelector);
// EXTERNAL MODULE: ./node_modules/.pnpm/style-loader@4.0.0_webpack@5.104.1/node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js
var setAttributesWithoutAttributes = __webpack_require__(12932);
var setAttributesWithoutAttributes_default = /*#__PURE__*/__webpack_require__.n(setAttributesWithoutAttributes);
// EXTERNAL MODULE: ./node_modules/.pnpm/style-loader@4.0.0_webpack@5.104.1/node_modules/style-loader/dist/runtime/insertStyleElement.js
var insertStyleElement = __webpack_require__(7296);
var insertStyleElement_default = /*#__PURE__*/__webpack_require__.n(insertStyleElement);
// EXTERNAL MODULE: ./node_modules/.pnpm/style-loader@4.0.0_webpack@5.104.1/node_modules/style-loader/dist/runtime/styleTagTransform.js
var styleTagTransform = __webpack_require__(32077);
var styleTagTransform_default = /*#__PURE__*/__webpack_require__.n(styleTagTransform);
// EXTERNAL MODULE: ./node_modules/.pnpm/css-loader@7.1.2_@rspack+core@1.7.1_webpack@5.104.1/node_modules/css-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[1]!./node_modules/.pnpm/vue-loader@15.9.8_@vue+compiler-sfc@3.5.26_css-loader@7.1.2_@rspack+core@1.7.1_webpack@_1aa4f1bbe7085d478bfddd6730367f21/node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/.pnpm/sass-loader@10.5.2_sass@1.32.13_webpack@5.104.1/node_modules/sass-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[2]!./node_modules/.pnpm/vue-loader@15.9.8_@vue+compiler-sfc@3.5.26_css-loader@7.1.2_@rspack+core@1.7.1_webpack@_1aa4f1bbe7085d478bfddd6730367f21/node_modules/vue-loader/lib/index.js??vue-loader-options!./src/components/VabPageHeader/index.vue?vue&type=style&index=0&lang=scss&
var VabPageHeadervue_type_style_index_0_lang_scss_ = __webpack_require__(78007);
;// CONCATENATED MODULE: ./node_modules/.pnpm/style-loader@4.0.0_webpack@5.104.1/node_modules/style-loader/dist/cjs.js!./node_modules/.pnpm/css-loader@7.1.2_@rspack+core@1.7.1_webpack@5.104.1/node_modules/css-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[1]!./node_modules/.pnpm/vue-loader@15.9.8_@vue+compiler-sfc@3.5.26_css-loader@7.1.2_@rspack+core@1.7.1_webpack@_1aa4f1bbe7085d478bfddd6730367f21/node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/.pnpm/sass-loader@10.5.2_sass@1.32.13_webpack@5.104.1/node_modules/sass-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[2]!./node_modules/.pnpm/vue-loader@15.9.8_@vue+compiler-sfc@3.5.26_css-loader@7.1.2_@rspack+core@1.7.1_webpack@_1aa4f1bbe7085d478bfddd6730367f21/node_modules/vue-loader/lib/index.js??vue-loader-options!./src/components/VabPageHeader/index.vue?vue&type=style&index=0&lang=scss&

      
      
      
      
      
      
      
      
      

var options = {};

options.styleTagTransform = (styleTagTransform_default());
options.setAttributes = (setAttributesWithoutAttributes_default());
options.insert = insertBySelector_default().bind(null, "head");
options.domAPI = (styleDomAPI_default());
options.insertStyleElement = (insertStyleElement_default());

var update = injectStylesIntoStyleTag_default()(VabPageHeadervue_type_style_index_0_lang_scss_["default"], options);




       /* export default */ var components_VabPageHeadervue_type_style_index_0_lang_scss_ = (VabPageHeadervue_type_style_index_0_lang_scss_["default"] && VabPageHeadervue_type_style_index_0_lang_scss_["default"].locals ? VabPageHeadervue_type_style_index_0_lang_scss_["default"].locals : undefined);

;// CONCATENATED MODULE: ./src/components/VabPageHeader/index.vue?vue&type=style&index=0&lang=scss&

// EXTERNAL MODULE: ./node_modules/.pnpm/vue-loader@15.9.8_@vue+compiler-sfc@3.5.26_css-loader@7.1.2_@rspack+core@1.7.1_webpack@_1aa4f1bbe7085d478bfddd6730367f21/node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__(30657);
;// CONCATENATED MODULE: ./src/components/VabPageHeader/index.vue



;


/* normalize component */

var component = (0,componentNormalizer["default"])(
  components_VabPageHeadervue_type_script_lang_js_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* export default */ var VabPageHeader = (component.exports);

}),
58119: (function (__unused_rspack_module, __webpack_exports__, __webpack_require__) {
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": function() { return /* binding */ mall_goodsList; }
});

;// CONCATENATED MODULE: ./node_modules/.pnpm/vue-loader@15.9.8_@vue+compiler-sfc@3.5.26_css-loader@7.1.2_@rspack+core@1.7.1_webpack@_1aa4f1bbe7085d478bfddd6730367f21/node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/.pnpm/vue-loader@15.9.8_@vue+compiler-sfc@3.5.26_css-loader@7.1.2_@rspack+core@1.7.1_webpack@_1aa4f1bbe7085d478bfddd6730367f21/node_modules/vue-loader/lib/index.js??vue-loader-options!./src/views/mall/goodsList/index.vue?vue&type=template&id=5a64b9e8&scoped=true&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticClass:"goods-list-container"},[_c('vab-page-header',{attrs:{"description":"商品展示页面，支持搜索、分页等功能","icon":['fas', 'shopping-bag'],"title":"商品列表"}}),_c('vab-query-form',[_c('vab-query-form-right-panel',{attrs:{"span":24}},[_c('el-form',{ref:"form",attrs:{"inline":true,"model":_vm.queryForm},nativeOn:{"submit":function($event){$event.preventDefault();}}},[_c('el-form-item',[_c('el-input',{attrs:{"placeholder":"商品名称"},model:{value:(_vm.queryForm.title),callback:function ($$v) {_vm.$set(_vm.queryForm, "title", $$v)},expression:"queryForm.title"}})],1),_c('el-form-item',[_c('el-button',{attrs:{"icon":"el-icon-search","native-type":"submit","type":"primary"},on:{"click":_vm.handleQuery}},[_vm._v("查询")])],1)],1)],1)],1),_c('el-row',{attrs:{"gutter":20}},_vm._l((_vm.list),function(item,index){return _c('el-col',{key:index,attrs:{"lg":8,"md":8,"sm":8,"xl":6,"xs":24}},[_c('el-card',{attrs:{"body-style":{ padding: '0px' },"shadow":"hover"}},[_c('div',{staticClass:"goods-list-card-body"},[_c('div',{staticClass:"goods-list-tag-group"},[(item.isRecommend)?_c('el-tag',{attrs:{"hit":"","type":"success"}},[_vm._v("推荐")]):_vm._e(),(item.status === 0)?_c('el-tag',{attrs:{"hit":"","type":"danger"}},[_vm._v("缺货")]):_vm._e()],1),_c('div',{staticClass:"goods-list-image-group"},[_c('img',{staticClass:"goods-list-image",attrs:{"src":item.image}})]),_c('div',{staticClass:"goods-list-title"},[_vm._v("\n            "+_vm._s(item.title)+"\n          ")]),_c('div',{staticClass:"goods-list-description"},[_vm._v("\n            "+_vm._s(item.description)+"\n          ")]),_c('div',{staticClass:"goods-list-price"},[_c('span',[_vm._v("¥ "+_vm._s(item.price)+" 元")])])])])],1)}),1),_c('el-pagination',{attrs:{"background":"","current-page":_vm.queryForm.pageNo,"layout":_vm.layout,"page-size":_vm.queryForm.pageSize,"total":_vm.total},on:{"current-change":_vm.handleCurrentChange,"size-change":_vm.handleSizeChange}})],1)}
var staticRenderFns = []


// EXTERNAL MODULE: ./src/api/goodsList.js
var goodsList = __webpack_require__(77322);
// EXTERNAL MODULE: ./src/components/VabPageHeader/index.vue + 5 modules
var VabPageHeader = __webpack_require__(94832);
;// CONCATENATED MODULE: ./node_modules/.pnpm/babel-loader@10.0.0_@babel+core@7.28.5_webpack@5.104.1/node_modules/babel-loader/lib/index.js??clonedRuleSet-1[0].rules[0].use!./node_modules/.pnpm/vue-loader@15.9.8_@vue+compiler-sfc@3.5.26_css-loader@7.1.2_@rspack+core@1.7.1_webpack@_1aa4f1bbe7085d478bfddd6730367f21/node_modules/vue-loader/lib/index.js??vue-loader-options!./src/views/mall/goodsList/index.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//



/* export default */ var goodsListvue_type_script_lang_js_ = ({
  name: 'Goods',
  components: {
    VabPageHeader: VabPageHeader["default"]
  },
  data() {
    return {
      queryForm: {
        pageNo: 1,
        pageSize: 20,
        title: ''
      },
      list: null,
      listLoading: true,
      layout: 'total, sizes, prev, pager, next, jumper',
      total: 0,
      elementLoadingText: '正在加载...'
    };
  },
  created() {
    this.fetchData();
  },
  methods: {
    handleSizeChange(val) {
      this.queryForm.pageSize = val;
      this.fetchData();
    },
    handleCurrentChange(val) {
      this.queryForm.pageNo = val;
      this.fetchData();
    },
    handleQuery() {
      this.queryForm.pageNo = 1;
      this.fetchData();
    },
    async fetchData() {
      this.listLoading = true;
      const {
        data,
        totalCount
      } = await (0,goodsList.getList)(this.queryForm);
      this.list = data;
      this.total = totalCount;
    }
  }
});
;// CONCATENATED MODULE: ./src/views/mall/goodsList/index.vue?vue&type=script&lang=js&
 /* export default */ var mall_goodsListvue_type_script_lang_js_ = (goodsListvue_type_script_lang_js_); 
// EXTERNAL MODULE: ./node_modules/.pnpm/style-loader@4.0.0_webpack@5.104.1/node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js
var injectStylesIntoStyleTag = __webpack_require__(64812);
var injectStylesIntoStyleTag_default = /*#__PURE__*/__webpack_require__.n(injectStylesIntoStyleTag);
// EXTERNAL MODULE: ./node_modules/.pnpm/style-loader@4.0.0_webpack@5.104.1/node_modules/style-loader/dist/runtime/styleDomAPI.js
var styleDomAPI = __webpack_require__(27381);
var styleDomAPI_default = /*#__PURE__*/__webpack_require__.n(styleDomAPI);
// EXTERNAL MODULE: ./node_modules/.pnpm/style-loader@4.0.0_webpack@5.104.1/node_modules/style-loader/dist/runtime/insertBySelector.js
var insertBySelector = __webpack_require__(51511);
var insertBySelector_default = /*#__PURE__*/__webpack_require__.n(insertBySelector);
// EXTERNAL MODULE: ./node_modules/.pnpm/style-loader@4.0.0_webpack@5.104.1/node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js
var setAttributesWithoutAttributes = __webpack_require__(12932);
var setAttributesWithoutAttributes_default = /*#__PURE__*/__webpack_require__.n(setAttributesWithoutAttributes);
// EXTERNAL MODULE: ./node_modules/.pnpm/style-loader@4.0.0_webpack@5.104.1/node_modules/style-loader/dist/runtime/insertStyleElement.js
var insertStyleElement = __webpack_require__(7296);
var insertStyleElement_default = /*#__PURE__*/__webpack_require__.n(insertStyleElement);
// EXTERNAL MODULE: ./node_modules/.pnpm/style-loader@4.0.0_webpack@5.104.1/node_modules/style-loader/dist/runtime/styleTagTransform.js
var styleTagTransform = __webpack_require__(32077);
var styleTagTransform_default = /*#__PURE__*/__webpack_require__.n(styleTagTransform);
// EXTERNAL MODULE: ./node_modules/.pnpm/css-loader@7.1.2_@rspack+core@1.7.1_webpack@5.104.1/node_modules/css-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[1]!./node_modules/.pnpm/vue-loader@15.9.8_@vue+compiler-sfc@3.5.26_css-loader@7.1.2_@rspack+core@1.7.1_webpack@_1aa4f1bbe7085d478bfddd6730367f21/node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/.pnpm/sass-loader@10.5.2_sass@1.32.13_webpack@5.104.1/node_modules/sass-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[2]!./node_modules/.pnpm/vue-loader@15.9.8_@vue+compiler-sfc@3.5.26_css-loader@7.1.2_@rspack+core@1.7.1_webpack@_1aa4f1bbe7085d478bfddd6730367f21/node_modules/vue-loader/lib/index.js??vue-loader-options!./src/views/mall/goodsList/index.vue?vue&type=style&index=0&id=5a64b9e8&lang=scss&scoped=true&
var goodsListvue_type_style_index_0_id_5a64b9e8_lang_scss_scoped_true_ = __webpack_require__(79464);
;// CONCATENATED MODULE: ./node_modules/.pnpm/style-loader@4.0.0_webpack@5.104.1/node_modules/style-loader/dist/cjs.js!./node_modules/.pnpm/css-loader@7.1.2_@rspack+core@1.7.1_webpack@5.104.1/node_modules/css-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[1]!./node_modules/.pnpm/vue-loader@15.9.8_@vue+compiler-sfc@3.5.26_css-loader@7.1.2_@rspack+core@1.7.1_webpack@_1aa4f1bbe7085d478bfddd6730367f21/node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/.pnpm/sass-loader@10.5.2_sass@1.32.13_webpack@5.104.1/node_modules/sass-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[2]!./node_modules/.pnpm/vue-loader@15.9.8_@vue+compiler-sfc@3.5.26_css-loader@7.1.2_@rspack+core@1.7.1_webpack@_1aa4f1bbe7085d478bfddd6730367f21/node_modules/vue-loader/lib/index.js??vue-loader-options!./src/views/mall/goodsList/index.vue?vue&type=style&index=0&id=5a64b9e8&lang=scss&scoped=true&

      
      
      
      
      
      
      
      
      

var options = {};

options.styleTagTransform = (styleTagTransform_default());
options.setAttributes = (setAttributesWithoutAttributes_default());
options.insert = insertBySelector_default().bind(null, "head");
options.domAPI = (styleDomAPI_default());
options.insertStyleElement = (insertStyleElement_default());

var update = injectStylesIntoStyleTag_default()(goodsListvue_type_style_index_0_id_5a64b9e8_lang_scss_scoped_true_["default"], options);




       /* export default */ var mall_goodsListvue_type_style_index_0_id_5a64b9e8_lang_scss_scoped_true_ = (goodsListvue_type_style_index_0_id_5a64b9e8_lang_scss_scoped_true_["default"] && goodsListvue_type_style_index_0_id_5a64b9e8_lang_scss_scoped_true_["default"].locals ? goodsListvue_type_style_index_0_id_5a64b9e8_lang_scss_scoped_true_["default"].locals : undefined);

;// CONCATENATED MODULE: ./src/views/mall/goodsList/index.vue?vue&type=style&index=0&id=5a64b9e8&lang=scss&scoped=true&

// EXTERNAL MODULE: ./node_modules/.pnpm/vue-loader@15.9.8_@vue+compiler-sfc@3.5.26_css-loader@7.1.2_@rspack+core@1.7.1_webpack@_1aa4f1bbe7085d478bfddd6730367f21/node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__(30657);
;// CONCATENATED MODULE: ./src/views/mall/goodsList/index.vue



;


/* normalize component */

var component = (0,componentNormalizer["default"])(
  mall_goodsListvue_type_script_lang_js_,
  render,
  staticRenderFns,
  false,
  null,
  "5a64b9e8",
  null
  
)

/* export default */ var mall_goodsList = (component.exports);

}),

}]);