"use strict";
(self["webpackChunkvue_admin_better"] = self["webpackChunkvue_admin_better"] || []).push([["2505"], {
35993: (function (module, __unused_webpack_exports, __webpack_require__) {
module.exports = __webpack_require__.p + "static/401.03b82ae6c95d71a9.png";

}),

}]);