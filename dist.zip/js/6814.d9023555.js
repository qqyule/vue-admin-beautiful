/*!
 * vue-admin-better
 * GitHub: https://github.com/zxwk1998/vue-admin-better
 * Gitee: https://gitee.com/chu1204505056/vue-admin-better
 *
 * 版权所有 (c) 2025 vue-admin-better
 * 本项目使用 MIT 许可证
 * 构建时间: 2025-8-7 15:25:32
 */
(self["webpackChunkvue_admin_better"] = self["webpackChunkvue_admin_better"] || []).push([["6814"], {
61698: (function (module, __unused_webpack_exports, __webpack_require__) {
/**
 * @description 3个子配置，通用配置|主题配置|网络配置
 */
//默认配置
const {
  setting,
  theme,
  network
} = __webpack_require__(84465);
module.exports = Object.assign({}, setting, theme, network);

}),

}]);