/*!
 * vue-admin-better
 * GitHub: https://github.com/zxwk1998/vue-admin-better
 * Gitee: https://gitee.com/chu1204505056/vue-admin-better
 *
 * 版权所有 (c) 2025 vue-admin-better
 * 本项目使用 MIT 许可证
 * 构建时间: 2025-11-12 15:25:30
 */
"use strict";
(self["webpackChunkvue_admin_better"] = self["webpackChunkvue_admin_better"] || []).push([["9908"], {
7007: (function (__unused_webpack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
__webpack_require__.d(__webpack_exports__, {
  getRepos: function() { return getRepos; },
  getStargazers: function() { return getStargazers; }
});
/* ESM import */var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5443);

function getRepos(params) {
  return (0,axios__WEBPACK_IMPORTED_MODULE_0__["default"])({
    url: 'https://api.github.com/repos/zxwk1998/vue-admin-better',
    method: 'get',
    params,
    timeout: 10000
  });
}
function getStargazers(params) {
  return (0,axios__WEBPACK_IMPORTED_MODULE_0__["default"])({
    url: 'https://api.github.com/repos/zxwk1998/vue-admin-better/stargazers',
    method: 'get',
    params,
    timeout: 10000
  });
}

}),

}]);